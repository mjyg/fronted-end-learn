const result = '我是文件2';

export default result;
