import data from './data.js';
console.log(data);
console.log('---------');
console.log('京程一灯');

// import('./index.wasm').then(() => {});
// import wasm from './index.wasm';
// console.log(wasm);
