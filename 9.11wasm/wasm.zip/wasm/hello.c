/*
编译方式：
1、可执行文件：
gcc hello.c -o hello
执行：./hello

2、编译成wasm在nodejs中执行
emcc hello.c -o hello_node.js
生成两个文件：
=> hello_node.wasm
=> hello_node.js
执行：
node hello_node.js

3、编译成wasm在浏览器中执行
emcc hello.c -s WASM=1 -O3 -o hello_html.html
其中 -s WASM=1 是制定要wasm文件； -O3 优化选项 ，优化选项中优化度最低是O1，优化度最高是O3

生成三个文件：
=> hello_html.wasm
=> hello_html.js
=> hello_html.html

执行：
在浏览器中执行，注意，生成的文件要放在web服务器中然后通过WEB访问，不能直接从硬盘访问
*/

#include<stdio.h>  // 引入标准输入输出库

int main(int argc, char const *argv[]) 
{
    /* code */
    printf("hello world!\n");   // console.log("hello world")
    return 0;
}

/**
// math.wasm 中的函数
int add( int a, int b)
{
    return a + b;
}

int square( int a)
{
    return a * a;
}
*/