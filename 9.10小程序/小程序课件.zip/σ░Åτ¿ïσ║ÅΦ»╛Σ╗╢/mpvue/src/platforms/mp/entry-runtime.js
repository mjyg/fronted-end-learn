/* @flow */

import Vue from './runtime/index'
import { createMP } from './runtime/lifecycle'

export default {
  Vue,
  createMP
}
