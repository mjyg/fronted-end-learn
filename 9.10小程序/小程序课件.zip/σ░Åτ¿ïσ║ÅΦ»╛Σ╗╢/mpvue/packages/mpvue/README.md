# mpvue

> This package is auto-generated. For pull requests please see [src/platforms/mp/entry-runtime.js](https://github.com/Meituan-Dianping/mpvue/blob/master/src/platforms/mp/entry-runtime.js).
