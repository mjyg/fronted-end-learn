var Direction5;
(function (Direction5) {
    Direction5["Up"] = "Up";
    Direction5["Down"] = "Down";
    Direction5["Left"] = "Left";
    Direction5["Right"] = "Right";
})(Direction5 || (Direction5 = {}));
var a = Direction5.Up;
