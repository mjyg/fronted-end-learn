1.使用 Drone 如何优化 npm install cache？



2.使用 Prometheus 统计 npm install、build 耗时。



3.利用 Grafana 对 Prometheus 的数据进行可视化。