### Docker 安装

安装必要的系统工具

```bash
yum install -y yum-utils device-mapper-persistent-data lvm2
```

添加软件源

```bash
yum-config-manager --add-repo http://mirrors.aliyun.com/docker-ce/linux/centos/docker-ce.repo
```

更新yum缓存

```bash
yum makecache fast
```

安装docker

```bash
yum -y install docker-ce
```

配置国内镜像源

```bash
curl -sSL http://oyh1cogl9.bkt.clouddn.com/setmirror.sh | sh -s <镜像加速地址>

curl -sSL http://oyh1cogl9.bkt.clouddn.com/setmirror.sh | sh -s http://dockerhub.azk8s.cn # Azure

# https://github.com/Azure/container-service-for-azure-china/blob/master/aks/README.md#22-container-registry-proxy
```

启动Docker

```bash
systemctl start docker
```

安装docker compose
```
curl -L "https://github.com/docker/compose/releases/download/1.24.0/docker-compose-$(uname -s)-$(uname -m)" -o /usr/local/bin/docker-compose
```

给docker compose可执行权限
```
chmod +x /usr/local/bin/docker-compose
```