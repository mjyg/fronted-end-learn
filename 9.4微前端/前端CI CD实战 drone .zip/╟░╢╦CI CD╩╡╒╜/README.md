课程目标:



1. 前端自动化构建部署从0-1的过程（Nginx）。



2. 熟悉 Drone 的基本原理。



3. 使用 Drone 构建部署前端应用。



4. 使用 Drone CLI Promote 指定环境。



5. 具备基于 Drone API 的运维系统开发能力。



drone.ci.yml项目代码，打开github repo里有，https://www.cntofu.com/book/139/cases/ci/drone.md  这篇文档也挺详细



vuepress模板搭建博客：https://blog.csdn.net/olewa_HHH/article/details/86618008



chrome  首页tab插件: https://github.com/jaywcjlove/oscnews
nginx 入门笔记: https://github.com/jaywcjlove/nginx-tutorial

