<template>
  <div class="hello">
    <h1 @click="increment">{{ count }}</h1>
    <hr />
    <h2>{{double}}</h2>
    <p>京程一灯Vue3 🏮</p>
  </div>
</template>

<script lang="ts">
// import { Component, Prop, Vue } from 'vue-property-decorator';

// @Component
// export default class HelloWorld extends Vue {
//   @Prop() private msg!: string;
// }
import {
  ref,
  Ref,
  defineComponent,
  computed,
  watchEffect,
  onMounted
} from "@vue/composition-api";
export default defineComponent({
  setup(props) {
    // const count = useState(0);
    // const {count,setCount} = count;
    const count: Ref<number> = ref(0);
    const increment = () => {
      count.value++;
    };
    const double = computed(() => count.value * 2);
    // watchEffect,
    onMounted(() => {
      console.log("onMounted");
    });
    console.log("🛫", "Vue3 Init");
    return {
      count,
      double,
      increment
    };
  }
});
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped lang="less">
h3 {
  margin: 40px 0 0;
}
ul {
  list-style-type: none;
  padding: 0;
}
li {
  display: inline-block;
  margin: 0 10px;
}
a {
  color: #42b983;
}
</style>
