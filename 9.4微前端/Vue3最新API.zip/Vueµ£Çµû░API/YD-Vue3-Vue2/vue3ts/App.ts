import {created} from "vue";
function App(){}
App.test = ()=>{
    created () {
        console.log("created");
    },
    watch(){}
}
export default App