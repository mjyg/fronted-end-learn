interface Ref<T> {
    value: T
}
function ref<T>(value: T): Ref<T>

const foo = ref<string | number>('foo') // foo's type: Ref<string | number>
foo.value = 123 // ok!
//vue3 源码 @types类型 提示d.ts
//vue2 ts开发 舒心 any interface 包
function reactive<T extends object>(raw: T): T 