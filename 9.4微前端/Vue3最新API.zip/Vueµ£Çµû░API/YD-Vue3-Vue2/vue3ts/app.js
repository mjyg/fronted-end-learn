import {createAPP} from "vue";
import App from "./App.vue";
const app = createAPP(App);
app.use()
app.mixin();
app.directive();


