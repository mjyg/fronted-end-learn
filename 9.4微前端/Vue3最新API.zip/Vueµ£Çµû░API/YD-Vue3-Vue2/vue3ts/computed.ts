// read-only
function computed<T>(getter: () => T): Readonly<Ref<Readonly<T>>>

// writable
function computed<T>(options: {
get: () => T,
set: (value: T) => void
}): Ref<T> 